import re
from pathlib import Path
from typing import Optional, Union

from ingenialink import CanBaudrate, CanDevice
from ingenialink.canopen.network import CanopenNetwork
from ingenialink.canopen.servo import CanopenServo
from ingenialink.eoe.network import EoENetwork
from ingenialink.ethercat.network import EthercatNetwork
from ingenialink.ethercat.servo import EthercatServo
from ingenialink.ethernet.network import EthernetNetwork
from ingenialink.ethernet.servo import EthernetServo
from ingenialink.network import Network
from ingenialink.servo import Servo
from packaging import version

from summit_testing_framework.setups import (
    DriveCanOpenSetup,
    DriveEcatSetup,
    DriveEoESetup,
    DriveEthernetSetup,
    DriveHwSetup,
    SetupDescriptor,
    VirtualDriveSetup,
)


def connect_ethernet(
    config: Union[DriveEthernetSetup, VirtualDriveSetup],
    net: Optional[EthernetNetwork] = None,
) -> tuple[EthernetServo, EthernetNetwork]:
    """Connect to Ethernet servo.

    Args:
        config: drive descriptor configuration.
        alias: servo alias.
        net: network, if not provided it will be created. Defaults to None

    Returns:
        Ethernet servo, Ethernet network.
    """
    if net is None:
        net = EthernetNetwork()
    servo = net.connect_to_slave(config.ip, config.dictionary.as_posix())
    return servo, net


def connect_canopen(
    config: DriveCanOpenSetup, net: Optional[CanopenNetwork] = None
) -> tuple[CanopenServo, CanopenNetwork]:
    """Connect to CANopen servo.

    Args:
        config: drive descriptor configuration.
        net: network, if not provided it will be created. Defaults to None

    Returns:
        CANopen servo, CANopen network.
    """
    if net is None:
        net = CanopenNetwork(
            device=CanDevice(config.device),
            channel=config.channel,
            baudrate=CanBaudrate(config.baudrate),
        )
    servo = net.connect_to_slave(
        target=config.node_id,
        dictionary=config.dictionary.as_posix(),
    )
    return servo, net


def connect_ethercat(
    config: DriveEcatSetup, net: Optional[EthercatNetwork] = None
) -> tuple[EthercatServo, EthercatNetwork]:
    """Connect to EtherCAT servo.

    Args:
        config: drive descriptor configuration.
        net: network, if not provided it will be created. Defaults to None

    Returns:
        EtherCAT servo, EtherCAT network.
    """
    if net is None:
        net = EthercatNetwork(config.ifname)
    servo = net.connect_to_slave(
        config.slave, config.dictionary.as_posix(), net_status_listener=True
    )
    return servo, net


def connect_eoe(
    config: DriveEoESetup, net: Optional[EoENetwork] = None
) -> tuple[EthernetServo, EoENetwork]:
    """Connect to EoE servo.

    Args:
        config: drive descriptor configuration.
        net: network, if not provided it will be created. Defaults to None

    Returns:
        Ethernet servo, EoE network.
    """
    if net is None:
        net = EoENetwork(config.ifname)
    servo = net.connect_to_slave(
        slave_id=config.slave, ip_address=config.ip, dictionary=config.dictionary.as_posix()
    )
    return servo, net


def connect_to_servo_with_protocol(
    descriptor: SetupDescriptor, net: Optional[Network] = None
) -> tuple[Servo, Network]:
    """Connect to a servo with a communication protocol.

    Args:
        descriptor: drive descriptor configuration.
        net: network, if not provided it will be created. Defaults to None.

    Returns:
        servo, network.

    Raises:
        ValueError: if the provided network does not match the communication
            protocol.
        NotImplementedError: if the communication protocol does not have a valid connection.
    """
    if isinstance(descriptor, DriveEcatSetup):
        if net is not None and not isinstance(net, EthercatNetwork):
            raise ValueError("Network should be of type EthercatNetwork.")
        return connect_ethercat(descriptor, net=net)
    elif isinstance(descriptor, DriveCanOpenSetup):
        if net is not None and not isinstance(net, CanopenNetwork):
            raise ValueError("Network should be of type CanopenNetwork.")
        return connect_canopen(descriptor, net=net)
    elif isinstance(descriptor, DriveEthernetSetup):
        if net is not None and not isinstance(net, EthernetNetwork):
            raise ValueError("Network should be of type EthernetNetwork.")
        return connect_ethernet(descriptor, net=net)
    elif isinstance(descriptor, DriveEoESetup):
        if net is not None and not isinstance(net, EoENetwork):
            raise ValueError("Network should be of type EoENetwork.")
        return connect_eoe(descriptor, net=net)
    raise NotImplementedError


def is_fw_already_uploaded(current_fw_version: str, firmware_file: Path) -> bool:
    """Checks if the specified firmware is already uploaded in a local configuration.

    Args:
        current_fw_version: firmware version loaded to the drive.
        firmware_file: firmware file to be loaded.

    Returns:
        True if the firmware is already loaded, False otherwise.
    """
    version_match = re.search(r"_(\d+\.\d+\.\d+)", firmware_file.stem)
    if version_match is None:
        return False
    file_fw_version = version_match.group(1)
    try:
        return version.parse(file_fw_version) == version.parse(current_fw_version)
    except version.InvalidVersion:
        return False


def load_firmware_with_protocol(servo: Servo, net: Network, descriptor: DriveHwSetup) -> None:
    """Load firmware to a servo with a communication protocol.

    Args:
        servo: servo.
        net: network.
        descriptor: drive descriptor configuration.

    Raises:
        ValueError: if the firmware file is not specified.
        RuntimeError: if firmware file is .zfu.
        TypeError: if read firmware version is not a string.
        NotImplementedError: if the communication protocol does not have a valid loading firmware
            functionality associated with.
    """
    if descriptor.fw_data.fw_file is None:
        raise ValueError("Firmware file must be specified.")
    if descriptor.fw_data.fw_file.suffix == ".zfu":
        raise RuntimeError(".lfu firmware file must be provided.")

    # Read the firmware version
    current_fw_version = servo.read("DRV_APP_COCO_VERSION", 0)
    if not isinstance(current_fw_version, str):
        raise TypeError("Firmware value has to be a string")
    if is_fw_already_uploaded(current_fw_version, descriptor.fw_data.fw_file):
        return

    if isinstance(descriptor, DriveEcatSetup):
        net.load_firmware(
            fw_file=descriptor.fw_data.fw_file.as_posix(),
            boot_in_app=descriptor.boot_in_app,
            slave_id=descriptor.slave,
        )
    elif isinstance(descriptor, DriveCanOpenSetup):
        net.load_firmware(int(servo.target), descriptor.fw_data.fw_file.as_posix())
    elif isinstance(descriptor, DriveEthernetSetup):
        net.load_firmware(
            fw_file=descriptor.fw_data.fw_file.as_posix(),
            ip=descriptor.ip,
            ftp_user="Ingenia",
            ftp_pwd="Ingenia",
        )
    else:
        raise NotImplementedError(
            f"Firmware loading not implemented for descriptor {type(descriptor)}"
        )
