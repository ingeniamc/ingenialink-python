from summit_testing_framework.setups import EmptySpecifier

TESTS_SETUP = EmptySpecifier()
