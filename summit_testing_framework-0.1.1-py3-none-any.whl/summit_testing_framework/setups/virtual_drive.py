from summit_testing_framework.setups.specifiers import VirtualDriveSpecifier

TESTS_SETUP = VirtualDriveSpecifier(ip="127.0.0.1", port=1061)
