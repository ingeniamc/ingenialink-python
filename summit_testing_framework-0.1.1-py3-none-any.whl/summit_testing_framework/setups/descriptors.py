from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Union

from ingenialink.dictionary import Interface

from summit_testing_framework.rack_service_client import RackServiceClient
from summit_testing_framework.setups.specifiers import (
    EmptySpecifier,
    LocalDriveConfigSpecifier,
    MultiLocalDriveConfigSpecifier,
    MultiRackServiceConfigSpecifier,
    RackServiceConfigSpecifier,
    SetupSpecifier,
    VirtualDriveSpecifier,
)

if TYPE_CHECKING:
    from collections.abc import Sequence


@dataclass(frozen=True)
class FirmwareData:
    """Defines the firmware data.

    Firmware data can be provided as a file path, or a revision number to be downloaded.
    """

    fw_file: Optional[Path]
    revision_number: Optional[str]

    def __post_init__(self) -> None:
        """Checks if the inputs are correct.

        Raises:
            ValueError: if the firmware file and the revision number are both provided.
        """
        if self.fw_file is not None and self.revision_number is not None:
            raise ValueError("Only file path or revision number can be provided.")


@dataclass(frozen=True)
class SetupDescriptor:
    """Generic setup."""


@dataclass(frozen=True)
class EmptySetupDescriptor(SetupDescriptor):
    """Use when no setup descriptor is needed for the tests."""


@dataclass(frozen=True)
class EthernetSetup(SetupDescriptor):
    """Any setup that uses Ethernet."""

    ip: str


@dataclass(frozen=True)
class VirtualDriveSetup(EthernetSetup):
    """Setup with virtual drive."""

    dictionary: Path
    port: int


@dataclass(frozen=True)
class DriveHwSetup(SetupDescriptor):
    """Setup with physical hw drive."""

    dictionary: Path
    identifier: str
    config_file: Optional[Path]
    fw_data: FirmwareData
    rack_drive_idx: Optional[int]
    rack_drive: Optional[Any]


@dataclass(frozen=True)
class DriveEthernetSetup(DriveHwSetup, EthernetSetup):
    """Setup with drive with Ethernet."""


@dataclass(frozen=True)
class DriveEoESetup(DriveHwSetup, EthernetSetup):
    """Setup with drive with EoE."""

    ifname: str
    slave: int


@dataclass(frozen=True)
class DriveEcatSetup(DriveHwSetup):
    """Setup with drive connected with Ethercat."""

    ifname: str
    slave: int
    boot_in_app: bool


@dataclass(frozen=True)
class DriveCanOpenSetup(DriveHwSetup):
    """Setup with drive connected with canopen."""

    device: str
    channel: int
    node_id: int
    baudrate: int


@dataclass(frozen=True)
class EthercatMultiSlaveSetup(SetupDescriptor):
    """Setup with multiple drives connected with Ethercat."""

    drives: list[DriveEcatSetup]


def _get_network_from_drive(drive: Any, interface: Interface) -> Any:
    if interface is Interface.CAN:
        attribute = "node_id"
    elif interface is Interface.ETH:
        attribute = "ip"
    elif interface is Interface.ECAT:
        attribute = "ifname"
    else:
        raise RuntimeError(f"No network associated with {interface=}")

    for node in drive.communications:
        if hasattr(node, attribute):
            return node
    raise RuntimeError(f"No network can be retrieved for {interface=}")


def _get_dictionary_and_firmware_file(
    specifier: RackServiceConfigSpecifier,
    rack_service_client: RackServiceClient,
    rack_drive_idx: int,
) -> tuple[Path, FirmwareData]:
    dictionary: Path = (
        specifier.dictionary
        if isinstance(specifier.dictionary, Path)
        else rack_service_client.get_dictionary(
            rack_drive_idx, specifier.dictionary.firmware_version, specifier.interface
        )
    )

    if isinstance(specifier.firmware_file, Path):
        firmware_data = FirmwareData(fw_file=specifier.firmware_file, revision_number=None)
    else:
        firmware_data = FirmwareData(
            fw_file=None, revision_number=specifier.firmware_file.firmware_version
        )
    return dictionary, firmware_data


def _descriptor_from_local_hw_specifier(
    specifier: Union[LocalDriveConfigSpecifier, MultiLocalDriveConfigSpecifier],
) -> SetupDescriptor:
    eval_specifiers = (
        specifier.specifiers
        if isinstance(specifier, MultiLocalDriveConfigSpecifier)
        else [specifier]
    )

    descriptors: list[DriveHwSetup] = []
    for eval_specifier in eval_specifiers:
        descriptor_args = {
            "dictionary": eval_specifier.dictionary,
            "identifier": eval_specifier.identifier,
            "config_file": eval_specifier.config_file,
            "fw_data": FirmwareData(
                fw_file=eval_specifier.firmware_file,
                revision_number=None,
            ),
            "rack_drive_idx": None,
            "rack_drive": None,
            **eval_specifier.interface_data,
        }
        if eval_specifier.interface is Interface.ETH:
            descriptors.append(DriveEthernetSetup(**descriptor_args))
        elif eval_specifier.interface is Interface.CAN:
            descriptors.append(DriveCanOpenSetup(**descriptor_args))
        elif eval_specifier.interface is Interface.ECAT:
            descriptors.append(DriveEcatSetup(**descriptor_args))
        elif eval_specifier.interface is Interface.EoE:
            descriptors.append(DriveEoESetup(**descriptor_args))
        else:
            raise RuntimeError(f"No descriptor for specifier {eval_specifier}")

    if isinstance(specifier, MultiLocalDriveConfigSpecifier):
        ecat_descriptors = [
            descriptor for descriptor in descriptors if isinstance(descriptor, DriveEcatSetup)
        ]
        if len(ecat_descriptors) != len(descriptors):
            raise RuntimeError(f"Ethercat multislave can not accept non Ethercat {descriptors=}")
        return EthercatMultiSlaveSetup(drives=ecat_descriptors)
    return descriptors[0]


def descriptor_from_specifier(
    specifier: SetupSpecifier, rack_service_client: Optional[RackServiceClient]
) -> SetupDescriptor:
    """Returns the setup descriptor that corresponds to a specifier.

    Args:
        specifier: setup specifier.
        rack_service_client: rack service client.
            If the specifier is a virtual drive specifier, should not be provided.

    Returns:
        Descriptor setup.

    Raises:
        RuntimeError: if the specifier is unknown.
        RuntimeError: if the specifier is a rack config specifier,
            but no rack service client is provided.
        RuntimeError: if no setup descriptor can be retrieved for the part number and interface.
        RuntimeError: if EthercatMultiSlaveSetup is attempted to be created with non Ethercat
            drive configurations.
    """
    if isinstance(specifier, EmptySpecifier):
        return EmptySetupDescriptor()

    if isinstance(specifier, VirtualDriveSpecifier):
        return VirtualDriveSetup(
            ip=specifier.ip, dictionary=specifier.dictionary, port=specifier.port
        )

    if isinstance(specifier, (LocalDriveConfigSpecifier, MultiLocalDriveConfigSpecifier)):
        return _descriptor_from_local_hw_specifier(specifier=specifier)

    if not isinstance(specifier, (RackServiceConfigSpecifier, MultiRackServiceConfigSpecifier)):
        raise RuntimeError(f"Unknown {specifier=}")

    if rack_service_client is None:
        raise RuntimeError(
            "Rack service client must be provided for rack service configuration specifier."
        )

    eval_specifiers: Sequence[RackServiceConfigSpecifier] = (
        specifier.specifiers
        if isinstance(specifier, MultiRackServiceConfigSpecifier)
        else [specifier]
    )

    descriptor: DriveHwSetup
    descriptors: list[DriveHwSetup] = []
    for eval_specifier in eval_specifiers:
        # Common arguments for DriveHwSetup
        rack_drive_idx, rack_drive = rack_service_client.get_drive(eval_specifier.part_number)
        dictionary, firmware_data = _get_dictionary_and_firmware_file(
            specifier=eval_specifier,
            rack_service_client=rack_service_client,
            rack_drive_idx=rack_drive_idx,
        )
        args = {
            "dictionary": dictionary,
            "identifier": rack_drive.identifier,
            "config_file": eval_specifier.config_file,
            "fw_data": firmware_data,
            "rack_drive_idx": rack_drive_idx,
            "rack_drive": rack_drive,
        }
        network = _get_network_from_drive(drive=rack_drive, interface=eval_specifier.interface)

        if eval_specifier.interface is Interface.ETH:
            descriptor = DriveEthernetSetup(**args, ip=network.ip)
        elif eval_specifier.interface is Interface.CAN:
            descriptor = DriveCanOpenSetup(
                **args,
                device=network.device,
                channel=network.channel,
                node_id=network.node_id,
                baudrate=network.baudrate,
            )
        elif eval_specifier.interface is Interface.ECAT:
            descriptor = DriveEcatSetup(
                **args, ifname=network.ifname, slave=network.slave, boot_in_app=network.boot_in_app
            )
        else:
            raise RuntimeError(
                f"No descriptor for part number {eval_specifier.part_number}, "
                f"interface {eval_specifier.interface}"
            )
        descriptors.append(descriptor)

    if isinstance(specifier, MultiRackServiceConfigSpecifier):
        ecat_descriptors = [
            descriptor for descriptor in descriptors if isinstance(descriptor, DriveEcatSetup)
        ]
        if len(ecat_descriptors) != len(descriptors):
            raise RuntimeError(f"Ethercat multislave can not accept non Ethercat {descriptors=}")
        return EthercatMultiSlaveSetup(drives=ecat_descriptors)
    return descriptors[0]
