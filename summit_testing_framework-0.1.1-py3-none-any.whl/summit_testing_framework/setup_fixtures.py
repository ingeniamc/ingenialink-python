import importlib
from collections.abc import Generator, Sequence
from pathlib import Path
from typing import TYPE_CHECKING, Optional, Union

import pytest
from ingenialink.drive_context_manager import DriveContextManager
from ingenialink.network import Network
from ingenialink.servo import Servo
from ingenialink.virtual.network import VirtualNetwork
from ingeniamotion import MotionController
from ingeniamotion.enums import SensorType
from pytest import FixtureRequest
from virtual_drive.core import VirtualDrive

from summit_testing_framework.import_utils import import_module_from_local_path
from summit_testing_framework.network_utils import (
    connect_ethercat,
    connect_to_servo_with_protocol,
    load_firmware_with_protocol,
)
from summit_testing_framework.rack_service_client import RackServiceClient
from summit_testing_framework.setups import (
    DriveCanOpenSetup,
    DriveEcatSetup,
    DriveEoESetup,
    DriveEthernetSetup,
    DriveHwSetup,
    EmptySpecifier,
    EthercatMultiSlaveSetup,
    LocalDriveConfigSpecifier,
    MultiLocalDriveConfigSpecifier,
    MultiRackServiceConfigSpecifier,
    RackServiceConfigSpecifier,
    SetupDescriptor,
    SetupSpecifier,
    VirtualDriveSetup,
    descriptor_from_specifier,
)
from summit_testing_framework.setups.environment_control import (
    DriveEnvironmentController,
    ManualUserEnvironmentController,
    RackServiceEnvironmentController,
    VirtualDriveEnvironmentController,
)

if TYPE_CHECKING:
    from types import ModuleType


def __get_descriptors(setup_descriptor: SetupDescriptor) -> Sequence[DriveHwSetup]:
    if isinstance(setup_descriptor, EthercatMultiSlaveSetup):
        return setup_descriptor.drives
    elif isinstance(setup_descriptor, DriveHwSetup):
        return [setup_descriptor]
    raise NotImplementedError(f"Can not get descriptors from {setup_descriptor=}")


@pytest.fixture(scope="session")
def skip_motion_controller(request: FixtureRequest) -> bool:
    """True if motion controller functionalities should be skipped.

    If skipped, only ingenialink functionalities will be enabled.

    Args:
        request: request.

    Returns:
        bool: True if motion controller should be skipped, False otherwise.

    Raises:
        ValueError: if flag is not boolean.
    """
    skip_mc = request.config.getoption("--skip_motion_controller")
    if not isinstance(skip_mc, bool):
        raise ValueError(f"Unexpected argument type: {skip_mc}, should be boolean.")
    return skip_mc


def determine_scope(fixture_name: str, config: pytest.Config) -> str:  # noqa: ARG001
    """Determines the scope of the function.

    If a unique slave connection is desired at the session start, the scope
    will be "session", "function" otherwise.

    Args:
        fixture_name: fixture name.
        config: pytest configuration.

    Returns:
        function scope.
    """
    if config.getoption("--refresh_slave_connection") is True:
        return "function"
    return "session"


@pytest.fixture(scope="session")
def rs_client(request: FixtureRequest) -> Generator[RackServiceClient, None, None]:
    """Connects to the rack service and yields the rack service client.

    Args:
        request: pytest request.

    Yields:
        Rack service client.
    """
    rack_service_client = RackServiceClient(job_name=request.config.getoption("--job_name"))
    yield rack_service_client
    rack_service_client.teardown()


@pytest.fixture(scope="session")
def setup_specifier(request: FixtureRequest) -> SetupSpecifier:
    """Setup specifier.

    The specifier must be provided using --setup addoption argument.

    Args:
        request: request.

    Returns:
        Setup specifier.

    Raises:
        ValueError: if the retrieved attribute is not a SetupSpecifier.
    """
    setup_option = request.config.getoption("--setup")
    setup_module: Optional[ModuleType]

    # Try to import from installed package
    try:
        module_path, attr_name = setup_option.rsplit(".", 1)
        setup_module = importlib.import_module(module_path)
        attr = getattr(importlib.import_module(module_path), attr_name)

    # Import from local file
    except ModuleNotFoundError:
        setup_location = Path(setup_option.replace(".", "/"))

        current_dir = Path.cwd().resolve()
        root_dir = Path(request.config.rootdir).resolve()  # type: ignore [attr-defined]
        if root_dir == current_dir:
            pass
        elif root_dir not in current_dir.parents:
            raise ValueError(
                f"Current directory {current_dir} is not a child of the root directory {root_dir}"
            )
        else:
            module_path = setup_location.parent.with_suffix(".py")
            # Find how many levels deep the current directory is from the root directory
            nested_level = len(current_dir.parts) - len(root_dir.parts)
            # Apply relative level
            for _ in range(nested_level):
                module_path = ".." / module_path

        setup_module = import_module_from_local_path(
            module_name=setup_location.parent.name, module_path=module_path.resolve()
        )

        attr = getattr(setup_module, setup_location.name)

    except Exception as e:
        raise e

    if not isinstance(attr, SetupSpecifier):
        raise ValueError(f"Retrieved attribute {attr} is not a SetupSpecifier")
    return attr


@pytest.fixture(scope="session")
def setup_descriptor(setup_specifier: SetupSpecifier, request: FixtureRequest) -> SetupDescriptor:
    """Generates the setup descriptor from the setup specifier.

    Args:
        setup_specifier: setup specifier.
        request: request.

    Returns:
        Setup descriptor.
    """
    if isinstance(setup_specifier, (RackServiceConfigSpecifier, MultiRackServiceConfigSpecifier)):
        rack_service_client = request.getfixturevalue("rs_client")
    else:
        rack_service_client = None

    return descriptor_from_specifier(
        specifier=setup_specifier, rack_service_client=rack_service_client
    )


@pytest.fixture(scope="session")
def with_motion_controller(skip_motion_controller: bool) -> None:
    """Checks if motion controller should be used.

    Args:
        skip_motion_controller: skip motion controller flag.

    Raises:
        ValueError: if skip motion controller flag is True.
    """
    if skip_motion_controller:
        raise ValueError("Motion controller should be enabled for this feature.")


def _is_specifier_empty(specifier: SetupSpecifier) -> bool:
    return isinstance(specifier, EmptySpecifier)


@pytest.fixture(scope="session")
def with_non_empty_specifier(setup_specifier: SetupSpecifier) -> None:
    """Checks if a non-empty specifier has been provided.

    Args:
        setup_specifier: setup specifier.

    Raises:
        ValueError: if empty specifier has been provided.
    """
    if _is_specifier_empty(setup_specifier):
        raise ValueError("EmptySpecifier is not valid for this feature.")


@pytest.fixture(scope=determine_scope)  # type: ignore [arg-type]
def setup_manager(
    with_non_empty_specifier: None,  # noqa: ARG001
    setup_specifier: SetupSpecifier,
    setup_descriptor: SetupDescriptor,
    pytestconfig: pytest.Config,
    request: FixtureRequest,
) -> Generator[
    tuple[Union[Servo, list[Servo]], Network, Union[str, list[str]], DriveEnvironmentController],
    None,
    None,
]:
    """Setup manager.

    It will connect to the servo(s) specified in the setup descriptor.
    The disconnection from the servo is handled automatically on the session end.

    WARNING: this only uses ingenialink functionalities.

    Args:
        with_non_empty_specifier: checks that a specifier has been provided.
        setup_specifier: setup specifier.
        setup_descriptor: setup descriptor.
        pytestconfig: pytestconfig.
        request: request.

    Yields:
        servo(s), network, servo alias(es), environment controller.

    Raises:
        NotImplementedError: if the setup descriptor is unknown.
    """
    default_alias: str = "default"
    alias_arg: list[str] = request.config.getoption("--alias")

    def _check_alias(alias: Union[str, list[str]]) -> Union[str, list[str]]:
        if not len(alias_arg):
            return alias

        expected_alias_length = 1 if isinstance(alias, str) else len(alias)
        if len(alias_arg) != expected_alias_length:
            raise ValueError(
                f"Provided alias={alias_arg}, does not match the specifier {setup_specifier}."
            )

        if expected_alias_length > 1:
            return alias_arg
        return alias_arg[0]

    environment: DriveEnvironmentController
    if isinstance(setup_descriptor, DriveHwSetup):
        if isinstance(setup_specifier, LocalDriveConfigSpecifier):
            environment = ManualUserEnvironmentController(pytestconfig)
        elif isinstance(setup_specifier, RackServiceConfigSpecifier):
            client = request.getfixturevalue("rs_client")
            environment = RackServiceEnvironmentController(
                client.client,
                default_drive_idx=setup_descriptor.rack_drive_idx,
            )
        else:
            raise NotImplementedError(
                f"Can't connect to drive from setup descriptor {setup_descriptor}"
            )
        servo, network = connect_to_servo_with_protocol(setup_descriptor)

        if setup_descriptor.config_file is not None:
            servo.restore_parameters()
            servo.load_configuration(setup_descriptor.config_file.as_posix())
        alias = _check_alias(alias=default_alias)
        yield servo, network, alias, environment
        environment.reset()
        network.disconnect_from_slave(servo)

    elif isinstance(setup_descriptor, EthercatMultiSlaveSetup):
        if isinstance(setup_specifier, MultiLocalDriveConfigSpecifier):
            environment = ManualUserEnvironmentController(pytestconfig)
        elif isinstance(setup_specifier, MultiRackServiceConfigSpecifier):
            client = request.getfixturevalue("rs_client")
            environment = RackServiceEnvironmentController(client.client)
        else:
            raise NotImplementedError(
                f"Can't connect to drive from setup descriptor {setup_descriptor}"
            )

        aliases = []
        servos = []
        for idx, drive in enumerate(setup_descriptor.drives):
            if idx == 0:
                servo, net = connect_ethercat(config=drive, net=None)
            else:
                servo, net = connect_ethercat(config=drive, net=net)
            servos.append(servo)
            aliases.append(drive.identifier)

        alias = _check_alias(alias=aliases)
        yield servos, net, alias, environment  # type: ignore [misc]
        environment.reset()
        for servo in servos:
            net.disconnect_from_slave(servo)

    elif isinstance(setup_descriptor, VirtualDriveSetup):
        virtual_drive = VirtualDrive(setup_descriptor.port, setup_descriptor.dictionary.as_posix())
        virtual_drive.start()
        network = VirtualNetwork()
        servo = network.connect_to_slave(virtual_drive.dictionary_path, virtual_drive.port)
        environment = VirtualDriveEnvironmentController(virtual_drive.environment)
        alias = _check_alias(alias=default_alias)
        yield servo, network, alias, environment
        environment.reset()
        virtual_drive.stop()
    else:
        raise NotImplementedError(
            f"Can't connect to drive from setup descriptor {setup_descriptor}"
        )


@pytest.fixture(scope=determine_scope)  # type: ignore [arg-type]
def _motion_controller_creator(
    with_motion_controller: None,  # noqa: ARG001
    setup_descriptor: SetupDescriptor,
    setup_manager: tuple[
        Union[Servo, list[Servo]], Network, Union[str, list[str]], DriveEnvironmentController
    ],
) -> Generator[MotionController, None, None]:
    """Motion controller creator.

    It will create a motion controller instance and assign the servos and network from
    setup_manager.

    Args:
        with_motion_controller: checks that motion controller is enabled.
        setup_descriptor: setup descriptor.
        setup_manager: interface controller.

    Raises:
        RuntimeError: if motion controller can not be created from retrieved
            servo and aliases.
        ValueError: if network can't be assigned.

    Yields:
        motion controller.
    """
    servo, net, alias, environment = setup_manager

    alias_to_servo: dict[str, Servo] = {}

    mc = MotionController()
    descriptors: Sequence[SetupDescriptor]
    if (
        isinstance(servo, list)
        and isinstance(alias, list)
        and isinstance(setup_descriptor, EthercatMultiSlaveSetup)
    ):
        alias_to_servo = dict(zip(alias, servo))
        descriptors = setup_descriptor.drives
    elif isinstance(servo, Servo) and isinstance(alias, str):
        alias_to_servo = {alias: servo}
        descriptors = [setup_descriptor]
    else:
        raise RuntimeError(f"Unexpected {servo=} and {net=}")
    mc.servos = alias_to_servo

    for servo_alias, descriptor in zip(alias_to_servo.keys(), descriptors):
        if isinstance(descriptor, DriveEthernetSetup):
            mc.net[servo_alias] = net
            mc.servo_net[servo_alias] = servo_alias
        elif isinstance(descriptor, DriveEoESetup):
            mc.net[descriptor.ifname] = net
            mc.servo_net[servo_alias] = descriptor.ifname
        elif isinstance(descriptor, DriveCanOpenSetup):
            net_key = f"{descriptor.device}_{descriptor.channel}_{descriptor.baudrate}"
            mc.net[net_key] = net
            mc.servo_net[servo_alias] = net_key
        elif isinstance(descriptor, DriveEcatSetup):
            mc.net[descriptor.ifname] = net
            mc.servo_net[servo_alias] = descriptor.ifname
        elif isinstance(descriptor, VirtualDriveSetup):
            mc.net[servo_alias] = net
            mc.servo_net[servo_alias] = servo_alias
        else:
            raise ValueError(f"Can not assign network for {descriptor=}")

    yield mc


@pytest.fixture(scope=determine_scope)  # type: ignore [arg-type]
def net(
    setup_manager: tuple[
        Union[Servo, list[Servo]], Network, Union[str, list[str]], DriveEnvironmentController
    ],
) -> Generator[Network, None, None]:
    """Network.

    Args:
        setup_manager: setup manager.

    Yields:
        network.
    """
    _, net, _, _ = setup_manager
    yield net


@pytest.fixture(scope=determine_scope)  # type: ignore [arg-type]
def environment(
    setup_manager: tuple[
        Union[Servo, list[Servo]], Network, Union[str, list[str]], DriveEnvironmentController
    ],
) -> Generator[DriveEnvironmentController, None, None]:
    """Environment.

    Args:
        setup_manager: setup manager.

    Yields:
        environment.
    """
    _, _, _, environment = setup_manager
    yield environment


@pytest.fixture(scope="function")
def servo(
    setup_manager: tuple[
        Union[Servo, list[Servo]], Network, Union[str, list[str]], DriveEnvironmentController
    ],
) -> Generator[Union[Servo, list[Servo]], None, None]:
    """Servo instance.

    Args:
        setup_manager: setup manager.

    Yields:
        servo(s).
    """
    servo, _, _, _ = setup_manager
    if isinstance(servo, list):
        context_managers = [DriveContextManager(s) for s in servo]
        for context_manager in context_managers:
            context_manager.__enter__()
        yield servo
        for context_manager in context_managers:
            context_manager.__exit__(None, None, None)
    else:
        context = DriveContextManager(servo)
        with context:
            yield servo


@pytest.fixture(scope=determine_scope)  # type: ignore [arg-type]
def alias(
    setup_manager: tuple[
        Union[Servo, list[Servo]], Network, Union[str, list[str]], DriveEnvironmentController
    ],
) -> Generator[Union[str, list[str]], None, None]:
    """Servo alias/es.

    Args:
        setup_manager: setup manager.

    Yields:
        alias(es).
    """
    _, _, alias, _ = setup_manager
    yield alias


@pytest.fixture
def mc(
    servo: Union[Servo, list[Servo]],  # noqa: ARG001
    _motion_controller_creator: MotionController,
) -> Generator[MotionController, None, None]:
    """Motion controller instance.

    Args:
        servo: servo instance. The fixture is used to ensure that if motion_controller
            fixture is used in a test to modify the servo, the servo will be restored.
        _motion_controller_creator: motion controller creator.

    Yields:
        motion controller.
    """
    yield _motion_controller_creator


@pytest.fixture(autouse=True)
def disable_motor_fixture(
    skip_motion_controller: bool,
    request: FixtureRequest,
    setup_descriptor: SetupDescriptor,
    setup_specifier: SetupSpecifier,
) -> Generator[None, None, None]:
    """Disables the motor on pytest session end.

    Args:
        skip_motion_controller: True to skip motion controller, False otherwise.
        request: request.
        setup_descriptor: setup descriptor.
        setup_specifier: setup specifier.

    Raises:
        ValueError: if the motor cannot be disabled for the setup descriptor.
    """
    run_fixture = (
        not skip_motion_controller
        and not _is_specifier_empty(setup_specifier)
        and not isinstance(setup_descriptor, VirtualDriveSetup)
    )
    if run_fixture:
        alias = request.getfixturevalue("alias")
        mc = request.getfixturevalue("_motion_controller_creator")

    yield
    if not run_fixture:
        return

    if not isinstance(setup_descriptor, (DriveHwSetup, EthercatMultiSlaveSetup)):
        raise ValueError(f"Cannot disable motor for {setup_descriptor=}")

    aliases = [alias] if isinstance(alias, str) else alias

    for eval_alias in aliases:
        mc.motion.motor_disable(servo=eval_alias)
        mc.motion.fault_reset(servo=eval_alias)


@pytest.fixture
def motion_controller_teardown(
    alias: Union[str, list[str]],
    mc: MotionController,
    setup_descriptor: SetupDescriptor,
) -> Generator[MotionController, None, None]:
    """Motion controller teardown.

    Args:
        alias: servo alias.
        mc: motion controller fixture.
        setup_descriptor: setup descriptor.

    Yields:
        Motion controller.

    Raises:
        ValueError: if cannot teardown motion controller.
    """
    yield mc

    if isinstance(setup_descriptor, VirtualDriveSetup):
        return

    if not isinstance(setup_descriptor, (DriveHwSetup, EthercatMultiSlaveSetup)):
        raise ValueError(f"Cannot teardown motion controller for {setup_descriptor=}")

    aliases = [alias] if isinstance(alias, str) else alias
    descriptors = __get_descriptors(setup_descriptor)

    for eval_alias, descriptor in zip(aliases, descriptors):
        mc.motion.motor_disable(servo=eval_alias)
        if descriptor.config_file is not None:
            mc.configuration.load_configuration(descriptor.config_file.as_posix(), servo=eval_alias)
        mc.motion.fault_reset(servo=eval_alias)


@pytest.fixture(scope=determine_scope)  # type: ignore [arg-type]
def feedback_list(
    alias: Union[str, list[str]], mc: MotionController
) -> Union[list[SensorType], list[list[SensorType]]]:
    """Servo feedback list.

    Args:
        alias: servo alias.
        mc: motion controller fixture.

    Returns:
        Feedback list.
    """
    aliases = [alias] if isinstance(alias, str) else alias

    fdbk_lst = [
        [
            mc.configuration.get_commutation_feedback(servo=eval_alias),
            mc.configuration.get_reference_feedback(servo=eval_alias),
            mc.configuration.get_velocity_feedback(servo=eval_alias),
            mc.configuration.get_position_feedback(servo=eval_alias),
            mc.configuration.get_auxiliar_feedback(servo=eval_alias),
        ]
        for eval_alias in aliases
    ]
    if isinstance(alias, str):
        return fdbk_lst[0]
    return fdbk_lst


@pytest.fixture
def clean_and_restore_feedbacks(
    alias: Union[str, list[str]], mc: MotionController
) -> Generator[None, None, None]:
    """Sets the feedbacks and restores them to the value they had before.

    Args:
        alias: servo alias.
        mc: motion controller fixture.
    """
    aliases = [alias] if isinstance(alias, str) else alias
    for eval_alias in aliases:
        comm = mc.configuration.get_commutation_feedback(servo=eval_alias)
        ref = mc.configuration.get_reference_feedback(servo=eval_alias)
        vel = mc.configuration.get_velocity_feedback(servo=eval_alias)
        pos = mc.configuration.get_position_feedback(servo=eval_alias)
        aux = mc.configuration.get_auxiliar_feedback(servo=eval_alias)
        mc.configuration.set_commutation_feedback(SensorType.INTGEN, servo=eval_alias)
        mc.configuration.set_reference_feedback(SensorType.INTGEN, servo=eval_alias)
        mc.configuration.set_velocity_feedback(SensorType.INTGEN, servo=eval_alias)
        mc.configuration.set_position_feedback(SensorType.INTGEN, servo=eval_alias)
        mc.configuration.set_auxiliar_feedback(SensorType.QEI, servo=eval_alias)
    yield
    for eval_alias in aliases:
        mc.configuration.set_commutation_feedback(comm, servo=eval_alias)
        mc.configuration.set_reference_feedback(ref, servo=eval_alias)
        mc.configuration.set_velocity_feedback(vel, servo=eval_alias)
        mc.configuration.set_position_feedback(pos, servo=eval_alias)
        mc.configuration.set_auxiliar_feedback(aux, servo=eval_alias)


@pytest.fixture(scope="module", autouse=True)
def load_configuration_after_each_module(
    skip_motion_controller: bool,
    request: FixtureRequest,
    setup_descriptor: SetupDescriptor,
    setup_specifier: SetupSpecifier,
) -> Generator[None, None, None]:
    """Loads the drive configuration.

    Args:
        skip_motion_controller: True to skip motion controller, False otherwise.
        request: request.
        setup_descriptor: setup descriptor.
        setup_specifier: setup specifier.

    Yields:
        Motion controller.

    Raises:
        ValueError: if the configuration cannot be loaded for the descriptor.
    """
    run_fixture = (
        not skip_motion_controller
        and not _is_specifier_empty(setup_specifier)
        and not isinstance(setup_descriptor, VirtualDriveSetup)
    )
    if run_fixture:
        alias = request.getfixturevalue("alias")
        mc = request.getfixturevalue("_motion_controller_creator")
    yield
    if not run_fixture:
        return

    if not isinstance(setup_descriptor, (DriveHwSetup, EthercatMultiSlaveSetup)):
        raise ValueError(f"Configuration cannot be loaded for {setup_descriptor=}")

    aliases = [alias] if isinstance(alias, str) else alias
    descriptors = __get_descriptors(setup_descriptor)

    for eval_alias, descriptor in zip(aliases, descriptors):
        mc.motion.motor_disable(servo=eval_alias)
        if descriptor.config_file is not None:
            mc.configuration.load_configuration(descriptor.config_file.as_posix(), servo=eval_alias)


@pytest.fixture(scope="session", autouse=True)
def load_firmware(
    setup_specifier: SetupSpecifier,
    setup_descriptor: SetupDescriptor,
    request: FixtureRequest,
) -> None:
    """Loads the firmware specified in the setup.

    If the firmware is already loaded, it will not be loaded again.

    Args:
        setup_specifier: setup specifier.
        setup_descriptor: setup descriptor.
        request: request.

    Raises:
        NotImplementedError: if there is no method to load firmware to the local descriptor's drive.
        RuntimeError: if the specifier is unknown.
        ValueError: if rack drive is not specified in a descriptor for a rack specifier.
    """
    if _is_specifier_empty(setup_specifier):
        return
    if isinstance(setup_descriptor, VirtualDriveSetup):
        return

    descriptors: Sequence[DriveHwSetup]
    if isinstance(setup_specifier, (LocalDriveConfigSpecifier, MultiLocalDriveConfigSpecifier)):
        if isinstance(setup_descriptor, EthercatMultiSlaveSetup):
            descriptors = setup_descriptor.drives
        elif isinstance(setup_descriptor, DriveHwSetup):
            descriptors = [setup_descriptor]
        else:
            raise NotImplementedError(f"Can not load firmware to {setup_descriptor=}")
        network_created = False
        for descriptor in descriptors:
            if descriptor.fw_data.fw_file is None:
                continue  # Firmware has not been specified, use the one that is already loaded
            if not network_created:
                servo, network = connect_to_servo_with_protocol(descriptor, None)
                network_created = True
            else:
                servo, network = connect_to_servo_with_protocol(descriptor, network)
            load_firmware_with_protocol(servo=servo, net=network, descriptor=descriptor)
            network.disconnect_from_slave(servo)
        return

    if not isinstance(
        setup_specifier, (RackServiceConfigSpecifier, MultiRackServiceConfigSpecifier)
    ):
        raise RuntimeError(f"Unknown {setup_specifier=}")

    client = request.getfixturevalue("rs_client")
    client.power_cycle()  # Reboot drive

    # Load firmware (if necessary, if it's already loaded it will do nothing)
    descriptors = __get_descriptors(setup_descriptor)
    for descriptor in descriptors:
        if descriptor.rack_drive is None:
            raise ValueError("Rack drive must be specified.")
        load_firmware_args = {
            "drive_idx": descriptor.rack_drive_idx,
            "product_code": descriptor.rack_drive.product_code,
            "serial_number": descriptor.rack_drive.serial_number,
        }
        if descriptor.fw_data.fw_file is not None:
            load_firmware_args["file"] = descriptor.fw_data.fw_file.as_posix()
        else:
            load_firmware_args["revision_number"] = descriptor.fw_data.revision_number
        client.client.firmware_load(**load_firmware_args)
